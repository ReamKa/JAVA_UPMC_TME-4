public class Histo{
	private int[] hist=new int[21];

	public Histo(){
		for(int i=0; i<this.hist.length; i++){
			this.hist[i]=0;
		}
	}

	public void addNote(int note){
		this.hist[note]=this.hist[note]+1;

	}

	public Histo(int[] tabnote){
		for(int i=0; i<tabnote.length; i++){
			this.hist[i]=tabnote[i];
		}
	}


	public void afficheHistogrammeTableau(){
		System.out.print("les valeurs du tableau histogramme sont ");
		for(int i=0; i<this.hist.length-1;i++){
			System.out.print(hist[i]+", ");
		}
		System.out.print(hist[hist.length-1]);

	}

	public void afficheHistogramme(){
		for(int i=0; i<this.hist.length;i++){
			System.out.print(i+" | ");
			for(int j=0; j<hist[i];j++){
				System.out.print("*");
			}
			System.out.println("\n");
		}
	}
}