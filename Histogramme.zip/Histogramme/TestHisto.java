public class TestHisto{
	public static void main(String[] args){
		int[] tab = new int[21];
		for(int i=0; i<150; i++){
			int k=(int)(Math.random()*21);
			tab[k]=tab[k]+1;
		}

		Histo h=new Histo(tab);
		h.afficheHistogramme();
		h.afficheHistogrammeTableau();


	}
}