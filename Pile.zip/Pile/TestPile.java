public class TestPile {
  public static void main (String[] args){

    Pile un = new Pile(4);
    Machin m1 = new Machin("Pepito",2);
    Machin m2 = new Machin("Mamita",4);
    Machin m3 = new Machin("Pipita",6);
    Machin m4 = new Machin("MegaBogoss",7);


    un.empiler(m1);
    System.out.println(un.toString());
    un.empiler(m2);
    System.out.println(un.toString());
    un.empiler(m3);
    System.out.println(un.toString());

    un.depiler();
    System.out.println(un.toString());
    un.depiler();
    System.out.println(un.toString());
    
    un.empiler(m4);
    System.out.println(un.toString());



  }
}
