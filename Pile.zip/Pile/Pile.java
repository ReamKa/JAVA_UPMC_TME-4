public class Pile {
  Machin [] tableau;
  int position = 0;

  public Pile(int tailleMaximale){
    tableau = new Machin [tailleMaximale];
  }

  public void empiler (Machin m){
    if (position == tableau.length){
      System.out.println("Le tableau est vide!");
    } else {
      tableau[position] = m;
      position++;
    }
  }

  public Machin depiler(){
    Machin m = null;
    if (position == 0){
      System.out.println("Le tableau est vide!\n");
    } else {
      m = tableau[position - 1];
      tableau[position - 1] = null;
      position --;
    }
    return m;
  }

  public boolean estVide(){
    return position == 0;
  }

  public boolean estPleine(){
    return position == tableau.length;
  }

  public String toString(){
    String s = " ";
    for(int i = 0; i < position; i++){
      s += tableau[i].getNom() + tableau[i].getValeur() + "\t";
    }
    return s;
  }
}
