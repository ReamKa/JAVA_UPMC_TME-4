public class Machin {
  String nom;
  int valeur;

  public Machin(String n, int v){
    this.nom = n;
    this.valeur = v;
  }

  public String getNom(){
    return nom;
  }

  public int getValeur(){
    return valeur;
  }



}
